
  // Import the functions you need from the SDKs you need
 
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyBYY5xGe7FiPk_BuI28NTCmwt-HCrOkwPQ",
    authDomain: "odia-delights-hub.firebaseapp.com",
    projectId: "odia-delights-hub",
    storageBucket: "odia-delights-hub.appspot.com",
    messagingSenderId: "811197669421",
    appId: "1:811197669421:web:a2f8efc874236f30d218a4",
    measurementId: "G-J223YS9CT9"
  };

  // Initialize Firebase
  const app = firebase.initializeApp(firebaseConfig);

